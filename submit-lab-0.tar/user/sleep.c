#include "kernel/types.h"
#include "user/user.h"

int main(int argc, char **argv)
{
  /* TODO: Insert your code here. */
  if (argc == 1) {
    printf("At least one argument is necessary");
    exit(1);
  }
  sleep(atoi(argv[1]));
  exit(0);
}
